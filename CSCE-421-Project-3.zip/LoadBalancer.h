#ifndef LOADBALANCER_H
#define LOADBALANCER_H
#include <vector>
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include "RequestQueue.h"
#include "WebServer.h"

#include <fstream>

class LoadBalancer {
public:
    LoadBalancer(int initialServers);
    ~LoadBalancer();
    void addRequest(const Request& request);
    void processRequests(int runtime);
    void addRandomRequest();
    void addGuaranteedRequest();
    int getLastProcessedServerId() const;

private:
    std::vector<WebServer*> servers;
    RequestQueue requestQueue;
    int currentTime;
    int totalProcessedRequests;
    int lastProcessedServerId;
    std::ofstream logFile;
    int minTaskTime;
    int maxTaskTime;
    
    void adjustServerCount();
    void addServer();
    void removeServer();
    void logStatus(const std::string& message);
};

#endif // LOADBALANCER_H
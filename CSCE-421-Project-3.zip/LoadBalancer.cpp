// LoadBalancer.cpp
#include "LoadBalancer.h"
#include <iostream>
#include <algorithm>
#include <numeric>
#include <ctime>
#include <iomanip>
LoadBalancer::LoadBalancer(int initialServers) : currentTime(0), totalProcessedRequests(0), lastProcessedServerId(-1) {
    for (int i = 0; i < initialServers; ++i) {
        addServer();
    }
    std::srand(std::time(0));

    // Open log file
    logFile.open("load_balancer_log.txt", std::ios::app);
    if (!logFile.is_open()) {
        std::cerr << "Failed to open log file!" << std::endl;
    }
    logStatus("Load Balancer initialized");
}

LoadBalancer::~LoadBalancer() {
    for (auto server : servers) {
        delete server;
    }
    if (logFile.is_open()) {
        logFile.close();
    }
}

void LoadBalancer::addRequest(const Request& request) {
    requestQueue.enqueue(request);
}

void LoadBalancer::processRequests(int runtime) {
    logStatus("Starting request processing");
    logStatus("Initial queue size: " + std::to_string(requestQueue.size()));

    while (currentTime < runtime) {
        for (auto& server : servers) {
            if (server->isAvailable() && !requestQueue.isEmpty()) {
                Request req = requestQueue.dequeue();
                server->processRequest(req);
                totalProcessedRequests++;
                lastProcessedServerId = server->getId();
                int taskTime = req.getTime();
                minTaskTime = std::min(minTaskTime, taskTime);
                maxTaskTime = std::max(maxTaskTime, taskTime);

                logStatus("Request processed by Server " + std::to_string(lastProcessedServerId) +
                          ", Time: " + std::to_string(taskTime));
            }
        }

        for (auto& server : servers) {
            if (!server->isAvailable()) {
                server->decrementProcessingTime();
                if (server->getProcessingTime() == 0) {
                    server->setAvailable(true);
                }
            }
        }

        adjustServerCount();
        currentTime++;
        addRandomRequest();
    }
    logStatus("Ending request processing");
    logStatus("Final queue size: " + std::to_string(requestQueue.size()));
    logStatus("Total processed requests: " + std::to_string(totalProcessedRequests));
    logStatus("Task time range: " + std::to_string(minTaskTime) + " - " + std::to_string(maxTaskTime));
}

void LoadBalancer::addRandomRequest() {
    if (std::rand() % 2 == 0) {
        std::string ipIn = "192.168.1." + std::to_string(std::rand() % 256);
        std::string ipOut = "192.168.1." + std::to_string(std::rand() % 256);
        int time = std::rand() % 20 + 10;
        char jobType = (std::rand() % 2) ? 'P' : 'S';
        Request newRequest(ipIn, ipOut, time, jobType);
        addRequest(newRequest);
        logStatus("New request added: IP " + ipIn + " -> " + ipOut + ", Time: " + std::to_string(time) + ", Type: " + jobType);
    }
}
void LoadBalancer::addGuaranteedRequest() {

    std::string ipIn = "192.168.1." + std::to_string(std::rand() % 256);
    std::string ipOut = "192.168.1." + std::to_string(std::rand() % 256);
    int time = std::rand() % 20 + 10;
    char jobType = (std::rand() % 2) ? 'P' : 'S';
    Request newRequest(ipIn, ipOut, time, jobType);
    addRequest(newRequest);

}

int LoadBalancer::getLastProcessedServerId() const {
    return lastProcessedServerId;
}

void LoadBalancer::adjustServerCount() {
    const int QUEUE_THRESHOLD_HIGH = 50;
    const int QUEUE_THRESHOLD_LOW = 10;
    const int MAX_SERVERS = 20;
    const int MIN_SERVERS = 1;

    if (requestQueue.size() > QUEUE_THRESHOLD_HIGH && servers.size() < MAX_SERVERS) {
        addServer();
    } else if (requestQueue.size() < QUEUE_THRESHOLD_LOW && servers.size() > MIN_SERVERS) {
        removeServer();
    }
}

void LoadBalancer::addServer() {
    int newId = servers.size() + 1;
    servers.push_back(new WebServer(newId));
    std::cout << "Server " << newId << " added. Total servers: " << servers.size() << std::endl;
}

void LoadBalancer::removeServer() {
    if (!servers.empty()) {
        WebServer* serverToRemove = servers.back();
        servers.pop_back();
        delete serverToRemove;
        std::cout << "Server removed. Total servers: " << servers.size() << std::endl;
    }
}

void LoadBalancer::logStatus(const std::string& message) {
    if (logFile.is_open()) {
        logFile << message << std::endl;
    }
}
